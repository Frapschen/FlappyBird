﻿#include "FB_headfile.h"

int main()
{
	bool isfirst=true;
	initgraph(288, 512);   // 创建绘图窗口，大小为 288x512 像素
	while (true)
	{
		play();
	
	}
 	_getch();
	closegraph();


	
}
